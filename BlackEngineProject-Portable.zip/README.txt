Black Engine Project - Portable Release Package 
============================================ 
 
Contents: 
- BlackEngineProject.exe: Main game executable 
- TileMapEditor.exe: Map editor 
- assets/: Game assets (sprites, audio, maps, etc.) 
- *.dll files: Visual C++ Runtime libraries 
 
Installation: 
1. Copy this folder to the target PC 
2. Run BlackEngineProject.exe to start the game 
 
If you get DLL errors, install: 
Microsoft Visual C++ Redistributable 2015-2022 
Download: https://aka.ms/vs/17/release/vc_redist.x64.exe 
